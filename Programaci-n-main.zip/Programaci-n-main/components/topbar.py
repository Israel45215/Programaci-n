import flet as ft
import theme


def _avatar_stack():
    """Grupo de avatares superpuestos (equipo activo)."""
    colors = [theme.PURPLE, theme.BLUE, theme.GREEN]
    avatars = []
    for i, c in enumerate(colors):
        avatars.append(
            ft.Container(
                width=30,
                height=30,
                border_radius=15,
                bgcolor=c,
                border=ft.Border.all(2, theme.BG_PAGE),
                margin=ft.Margin.only(left=0 if i == 0 else -10),
                alignment=ft.Alignment.CENTER,
                content=ft.Icon(ft.Icons.PERSON, size=14, color="#FFFFFF"),
            )
        )
    return ft.Row(avatars, spacing=0)


def build_topbar(admin_name: str = "Administrador") -> ft.Container:
    search_box = ft.Container(
        content=ft.Row(
            [
                ft.Icon(ft.Icons.SEARCH_ROUNDED, size=18, color=theme.TEXT_MUTED),
                ft.TextField(
                    hint_text="Buscar trabajador",
                    hint_style=ft.TextStyle(color=theme.TEXT_MUTED, size=13),
                    text_style=ft.TextStyle(color=theme.TEXT_PRIMARY, size=13),
                    border=ft.InputBorder.NONE,
                    height=36,
                    content_padding=ft.Padding.only(top=8),
                    expand=True,
                    cursor_color=theme.TEXT_PRIMARY,
                ),
            ],
            spacing=8,
        ),
        bgcolor=theme.BG_INPUT,
        border_radius=theme.RADIUS_PILL,
        padding=ft.Padding.symmetric(horizontal=16),
        width=340,
        height=42,
        alignment=ft.Alignment.CENTER_LEFT,
    )

    icon_button = lambda icon: ft.Container(
        content=ft.Icon(icon, size=18, color=theme.TEXT_SECONDARY),
        width=38,
        height=38,
        border_radius=19,
        bgcolor=theme.BG_INPUT,
        alignment=ft.Alignment.CENTER,
        ink=True,
    )

    calendar_dropdown = ft.Container(
        content=ft.Row(
            [
                ft.Icon(ft.Icons.CALENDAR_TODAY_ROUNDED, size=15, color=theme.TEXT_SECONDARY),
                ft.Text("Calendario", size=12.5, color=theme.TEXT_SECONDARY),
                ft.Icon(ft.Icons.KEYBOARD_ARROW_DOWN_ROUNDED, size=16, color=theme.TEXT_SECONDARY),
            ],
            spacing=6,
        ),
        bgcolor=theme.BG_INPUT,
        padding=ft.Padding.symmetric(horizontal=14, vertical=9),
        border_radius=theme.RADIUS_PILL,
    )

    return ft.Container(
        content=ft.Row(
            [
                search_box,
                ft.Container(expand=True),
                icon_button(ft.Icons.NOTIFICATIONS_ROUNDED),
                icon_button(ft.Icons.HELP_OUTLINE_ROUNDED),
                _avatar_stack(),
                calendar_dropdown,
            ],
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=ft.Padding.only(left=28, right=28, top=18, bottom=8),
    )
